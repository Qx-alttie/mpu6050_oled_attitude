# Build the STM32 firmware with arm-none-eabi-gcc directly (no CMake needed).
# Usage:
#   .\build.ps1          # Release -> firmware\
#   .\build.ps1 -Debug   # Debug   -> firmware\debug\
param(
    [switch]$Debug
)

$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $root

$gcc = (Get-Command arm-none-eabi-gcc -ErrorAction SilentlyContinue).Source
if (-not $gcc) {
    $candidates = @(
        "D:\01_Tools\ARM-GCC\arm-gnu-toolchain-13.3.rel1-mingw-w64-i686-arm-none-eabi\bin\arm-none-eabi-gcc.exe",
        "D:\rmcode\stm32cubeclt\STM32CubeCLT_1.22.0\GNU-tools-for-STM32\bin\arm-none-eabi-gcc.exe"
    )
    foreach ($c in $candidates) {
        if (Test-Path $c) { $gcc = $c; break }
    }
}
if (-not $gcc) { throw "arm-none-eabi-gcc not found. Install ARM GNU Toolchain or add it to PATH." }

$objcopy = Join-Path (Split-Path $gcc) "arm-none-eabi-objcopy.exe"
if (-not (Test-Path $objcopy)) { throw "arm-none-eabi-objcopy.exe not found." }

$outDir = if ($Debug) { Join-Path $root "firmware\debug" } else { Join-Path $root "firmware" }
New-Item -ItemType Directory -Force $outDir | Out-Null

$sources = @(
    "Core\Src\main.c",
    "Core\Src\pid.c",
    "Core\Src\stm32f1xx_it.c",
    "Core\Src\stm32f1xx_hal_msp.c",
    "Core\Src\system_stm32f1xx.c",
    "Core\Src\sysmem.c",
    "Core\Src\syscalls.c",
    "startup_stm32f103xb.s",
    "Drivers\STM32F1xx_HAL_Driver\Src\stm32f1xx_hal_gpio_ex.c",
    "Drivers\STM32F1xx_HAL_Driver\Src\stm32f1xx_hal_i2c.c",
    "Drivers\STM32F1xx_HAL_Driver\Src\stm32f1xx_hal.c",
    "Drivers\STM32F1xx_HAL_Driver\Src\stm32f1xx_hal_rcc.c",
    "Drivers\STM32F1xx_HAL_Driver\Src\stm32f1xx_hal_rcc_ex.c",
    "Drivers\STM32F1xx_HAL_Driver\Src\stm32f1xx_hal_gpio.c",
    "Drivers\STM32F1xx_HAL_Driver\Src\stm32f1xx_hal_dma.c",
    "Drivers\STM32F1xx_HAL_Driver\Src\stm32f1xx_hal_cortex.c",
    "Drivers\STM32F1xx_HAL_Driver\Src\stm32f1xx_hal_pwr.c",
    "Drivers\STM32F1xx_HAL_Driver\Src\stm32f1xx_hal_flash.c",
    "Drivers\STM32F1xx_HAL_Driver\Src\stm32f1xx_hal_flash_ex.c",
    "Drivers\STM32F1xx_HAL_Driver\Src\stm32f1xx_hal_exti.c",
    "Drivers\STM32F1xx_HAL_Driver\Src\stm32f1xx_hal_uart.c",
    "Drivers\STM32F1xx_HAL_Driver\Src\stm32f1xx_hal_tim.c",
    "Drivers\STM32F1xx_HAL_Driver\Src\stm32f1xx_hal_tim_ex.c"
)

$gccArgs = @(
    "-mcpu=cortex-m3", "-mthumb",
    "-DUSE_HAL_DRIVER", "-DSTM32F103xB",
    "-ICore\Inc",
    "-IDrivers\STM32F1xx_HAL_Driver\Inc",
    "-IDrivers\STM32F1xx_HAL_Driver\Inc\Legacy",
    "-IDrivers\CMSIS\Device\ST\STM32F1xx\Include",
    "-IDrivers\CMSIS\Include",
    "-Wall", "-fdata-sections", "-ffunction-sections",
    "-T", "STM32F103xx_FLASH.ld",
    "--specs=nano.specs",
    "-Wl,--gc-sections",
    "-Wl,-Map=$outDir\Myproject.map",
    "-Wl,--print-memory-usage"
)
if ($Debug) {
    $gccArgs += @("-O0", "-g3", "-DDEBUG")
} else {
    $gccArgs += @("-Os", "-g0")
}
$gccArgs += $sources
$gccArgs += @("-lm", "-o", "$outDir\Myproject.elf")

Write-Host "GCC     : $gcc"
Write-Host "Output  : $outDir"
& $gcc @gccArgs
if ($LASTEXITCODE -ne 0) { throw "Build failed, exit code $LASTEXITCODE" }

& $objcopy -O ihex "$outDir\Myproject.elf" "$outDir\Myproject.hex"
& $objcopy -O binary "$outDir\Myproject.elf" "$outDir\Myproject.bin"
Get-ChildItem $outDir -Filter "Myproject.*" | Select-Object Name, Length, LastWriteTime
Write-Host "Build OK." -ForegroundColor Green

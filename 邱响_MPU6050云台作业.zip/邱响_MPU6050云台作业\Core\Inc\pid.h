#ifndef PID_H
#define PID_H

#include <stdint.h>

/* Pitch-axis closed-loop PID.
 *
 * The MPU6050 is mounted on the gimbal, so the measured variable is
 * MPU_PitchRelative() (degrees).  The controller output is a pulse-width
 * offset in microseconds and is added to the normal TIM2_CH2 pitch CCR.
 *
 * If the gimbal runs away when PID is enabled, the feedback direction is
 * wrong for this mounting: change PID_PITCH_SIGN to -1.0f and rebuild.
 */
#ifndef PID_PITCH_SIGN
#define PID_PITCH_SIGN        (+1.0f)
#endif

void PID_Init(void);
void PID_Enable(float target_deg);
void PID_Disable(void);
uint8_t PID_IsEnabled(void);
float PID_GetTarget(void);
float PID_GetOutput(void);
void PID_Update(float measured_deg, float dt);

#endif /* PID_H */

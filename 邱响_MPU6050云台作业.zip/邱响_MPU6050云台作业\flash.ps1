# ST-Link + OpenOCD flash helper.
# Usage: right-click "Run with PowerShell", or run .\flash.ps1

$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$elf  = Join-Path $root "firmware\Myproject.elf"

if (-not (Test-Path $elf)) {
    throw "Missing $elf. Build the firmware first."
}

$openocd = (Get-Command openocd -ErrorAction SilentlyContinue).Source
if (-not $openocd) {
    $candidates = @(
        "D:\01_Tools\OpenOCD\xpack-openocd-0.12.0-7\bin\openocd.exe",
        "C:\Program Files\OpenOCD\bin\openocd.exe",
        "C:\Program Files (x86)\OpenOCD\bin\openocd.exe"
    )
    foreach ($c in $candidates) {
        if (Test-Path $c) { $openocd = $c; break }
    }
}
if (-not $openocd) {
    throw "openocd.exe not found. Install OpenOCD or edit the path in this script."
}

Write-Host "OpenOCD : $openocd"
Write-Host "Firmware: $elf"
& $openocd -f interface/stlink.cfg -f target/stm32f1x.cfg `
    -c "program `"$elf`" verify reset exit"
if ($LASTEXITCODE -ne 0) {
    throw "Flash failed, exit code $LASTEXITCODE. Check ST-Link wiring and driver."
}
Write-Host "Flash OK. Press reset or power-cycle the board." -ForegroundColor Green

/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <math.h>
#include "pid.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* MPU6050, 7-bit address 0x68 (AD0 = GND) or 0x69 (AD0 = VCC). The HAL uses
 * the shifted address.  MPU_Init() probes both. */
#define MPU6050_ADDR_68           (0x68u << 1)
#define MPU6050_ADDR_69           (0x69u << 1)
#define MPU6050_REG_SMPLRT_DIV    0x19u
#define MPU6050_REG_CONFIG        0x1Au
#define MPU6050_REG_GYRO_CONFIG   0x1Bu
#define MPU6050_REG_ACCEL_CONFIG  0x1Cu
#define MPU6050_REG_ACCEL_XOUT_H  0x3Bu
#define MPU6050_REG_PWR_MGMT_1    0x6Bu
#define MPU6050_REG_WHO_AM_I      0x75u
#define MPU6050_TIMEOUT           100u
#define MPU6050_ACCEL_SCALE       16384.0f   /* +/-2 g  */
#define MPU6050_GYRO_SCALE        65.5f      /* +/-500 deg/s */
#define MPU6050_ALPHA             0.98f
#define MPU6050_CALIB_SAMPLES     200u

/* --------------------------------------------------------------------------
 * Gimbal / servo configuration
 *   TIM2_CH1 = PA0 -> pan servo
 *   TIM2_CH2 = PA1 -> tilt servo
 * Both channels run at 50 Hz with a 0.5-2.5 ms pulse.
 * -------------------------------------------------------------------------- */
/* SG90/MG90 full-travel pulse range.  The common "1-2 ms" range only covers
 * about 90-120 degrees on many hobby servos, which made the gimbal feel like
 * it barely moved.  0.5-2.5 ms gives the full 0-180 degree command range.
 * If a particular servo buzzes at the endpoints, narrow this to 600/2400. */
#define SERVO_PWM_MIN_US          500u
#define SERVO_PWM_MAX_US          2500u
#define SERVO_ANGLE_MIN           0.0f
#define SERVO_ANGLE_MAX           180.0f
#define SERVO_CENTER_DEG          90.0f

/* Mechanical range.  SG90/MG90 usually accept 0..180 deg; if the gimbal
 * binds at an endpoint, reduce these limits before powering the servos. */
#define SERVO_PAN_MIN_DEG         0.0f
#define SERVO_PAN_MAX_DEG         180.0f
#define SERVO_TILT_MIN_DEG        0.0f
#define SERVO_TILT_MAX_DEG        180.0f

/* Per-axis trim and direction.  Flip INVERT to 1 if a servo runs backwards. */
#define SERVO_PAN_TRIM_DEG        0.0f
#define SERVO_TILT_TRIM_DEG       0.0f
#define SERVO_PAN_INVERT          0
#define SERVO_TILT_INVERT         0

#define SERVO_DEFAULT_SPEED_DPS   90.0f
#define SERVO_SPEED_MIN_DPS       10.0f
#define SERVO_SPEED_MAX_DPS       180.0f
#define SERVO_UPDATE_MS           10u

/* One W/S/A/D key press moves the target by this many degrees. */
#define KEY_STEP_DEG              10.0f

/* --------------------------------------------------------------------------
 * Mounting compensation for the MPU6050 glued to the gimbal platform.
 * 0 = normal (Z up), 1 = upside down (180 deg about X), 2 = 180 deg about Y,
 * 3 = 180 deg about Z.  MOUNT 0..3 can also be sent over the serial port.
 * If a flat platform reports Roll near +/-180, try MOUNT 1 first.
 * -------------------------------------------------------------------------- */
#define MPU_MOUNT_MODE_DEFAULT    0u

/* --------------------------------------------------------------------------
 * Serial command buffer.  UART RX is interrupt driven so a command is not
 * lost while the OLED frame is being pushed over I2C.
 * -------------------------------------------------------------------------- */
#define UART_RX_RING_SIZE         128u
#define UART_LINE_SIZE            64u

#define FW_VERSION                "1.1.0"
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
I2C_HandleTypeDef hi2c1;
TIM_HandleTypeDef htim2;

UART_HandleTypeDef huart1;

/* USER CODE BEGIN PV */
static uint32_t uart_report_tick;
static uint32_t uart_led_tick;
static uint32_t uart_stream_tick;
static uint32_t uart_raw_tick;

/* UART RX ring buffer, filled from the USART1 interrupt. */
static uint8_t uart_rx_byte;
static volatile uint8_t  uart_rx_ring[UART_RX_RING_SIZE];
static volatile uint16_t uart_rx_head;
static volatile uint16_t uart_rx_tail;

static char    uart_line[UART_LINE_SIZE];
static uint8_t uart_line_len;

/* MPU6050 state, kept volatile so ST-Link can read it while running. */
volatile uint8_t  mpu_state;
volatile int32_t  mpu_roll_x10;
volatile int32_t  mpu_pitch_x10;
volatile uint32_t mpu_sample_count;
volatile int16_t  mpu_ax;
volatile int16_t  mpu_ay;
volatile int16_t  mpu_az;
volatile int16_t  mpu_gx;
volatile int16_t  mpu_gy;
volatile int16_t  mpu_gz;
volatile int32_t  mpu_roll_acc_x10;
volatile int32_t  mpu_pitch_acc_x10;
volatile uint8_t  mpu_mount_mode;
static uint16_t   mpu_addr;

static float   mpu_roll;
static float   mpu_pitch;
static float   mpu_gyro_bias_x;
static float   mpu_gyro_bias_y;
static float   mpu_gyro_bias_z;
static float   mpu_roll_zero;
static float   mpu_pitch_zero;
static uint8_t mpu_zero_active;
static uint8_t mpu_first_sample;
static uint32_t mpu_tick;
static uint32_t oled_ui_tick;

/* Two-axis gimbal state.  current_deg moves smoothly toward target_deg. */
typedef struct
{
  float    current_deg;
  float    target_deg;
  uint16_t pulse_us;
} ServoAxis;

static ServoAxis servo_pan;
static ServoAxis servo_tilt;
static float     servo_speed_dps;
static uint32_t  servo_tick;

static uint8_t  sweep_enabled;
static uint8_t  sweep_phase;
static uint32_t sweep_tick;

static uint8_t  stream_enabled;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART1_UART_Init(void);
static void MX_I2C1_Init(void);
static void MX_TIM2_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* ==========================================================================
 * SSD1306 128x64 OLED driver (I2C1: PB6 = SCL, PB7 = SDA)
 * All of this code lives inside USER CODE sections, so regenerating the
 * project from STM32CubeMX keeps it untouched.
 * ========================================================================== */

#define OLED_WIDTH       128u
#define OLED_HEIGHT      64u
#define OLED_PAGES       (OLED_HEIGHT / 8u)
#define OLED_CTRL_CMD    0x00u
#define OLED_CTRL_DATA   0x40u
#define OLED_TIMEOUT     100u

/* 1 = SSD1306 answered and the first frame was sent, 0 = not displayed.
 * Kept as a volatile global so a debugger can read it over SWD. */
volatile uint8_t oled_state;

/* Panel address actually used (already shifted for HAL) and the result of the
 * start-up bus scan. All of it stays readable over SWD. */
static uint16_t oled_addr = (uint16_t)(0x3Cu << 1);
volatile uint8_t i2c_dev_count;
volatile uint8_t i2c_ack_map[8];

static uint8_t oled_buffer[OLED_PAGES][OLED_WIDTH];
static uint8_t oled_tx[OLED_WIDTH + 1u];

/* 8 wide x 16 high glyphs, printable ASCII 0x20..0x7E, one byte per row,
 * MSB = leftmost pixel. */
static const uint8_t font8x16[95][16] = {
  { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 }, /* 32 ' ' */
  { 0x00, 0x00, 0x00, 0x00, 0x00, 0x18, 0x18, 0x08, 0x08, 0x08, 0x00, 0x08, 0x08, 0x00, 0x00, 0x00 }, /* 33 '!' */
  { 0x00, 0x00, 0x00, 0x00, 0x00, 0x34, 0x34, 0x34, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 }, /* 34 '"' */
  { 0x00, 0x00, 0x00, 0x00, 0x00, 0x16, 0x14, 0x7E, 0x34, 0x34, 0x7E, 0x24, 0x24, 0x00, 0x00, 0x00 }, /* 35 '#' */
  { 0x00, 0x00, 0x00, 0x00, 0x08, 0x3E, 0x28, 0x38, 0x3C, 0x1E, 0x1E, 0x1E, 0x7C, 0x10, 0x00, 0x00 }, /* 36 '$' */
  { 0x00, 0x00, 0x00, 0x00, 0x00, 0x32, 0x56, 0x5C, 0x38, 0x1E, 0x1A, 0x2A, 0x66, 0x00, 0x00, 0x00 }, /* 37 '%' */
  { 0x00, 0x00, 0x00, 0x00, 0x00, 0x3C, 0x24, 0x2C, 0x38, 0x3A, 0x6E, 0x66, 0x3E, 0x00, 0x00, 0x00 }, /* 38 '&' */
  { 0x00, 0x00, 0x00, 0x00, 0x00, 0x18, 0x08, 0x08, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 }, /* 39 ''' */
  { 0x00, 0x00, 0x00, 0x00, 0x04, 0x0C, 0x18, 0x10, 0x10, 0x10, 0x10, 0x10, 0x18, 0x0C, 0x04, 0x00 }, /* 40 '(' */
  { 0x00, 0x00, 0x00, 0x00, 0x10, 0x18, 0x08, 0x0C, 0x0C, 0x04, 0x0C, 0x0C, 0x08, 0x18, 0x10, 0x00 }, /* 41 ')' */
  { 0x00, 0x00, 0x00, 0x00, 0x00, 0x08, 0x3E, 0x1C, 0x3E, 0x08, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 }, /* 42 '*' */
  { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x08, 0x08, 0x7E, 0x08, 0x08, 0x00, 0x00, 0x00, 0x00 }, /* 43 '+' */
  { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x18, 0x18, 0x08, 0x30, 0x00 }, /* 44 ',' */
  { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x3C, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 }, /* 45 '-' */
  { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x18, 0x18, 0x00, 0x00, 0x00 }, /* 46 '.' */
  { 0x00, 0x00, 0x00, 0x00, 0x00, 0x06, 0x04, 0x0C, 0x08, 0x18, 0x10, 0x30, 0x30, 0x20, 0x00, 0x00 }, /* 47 '/' */
  { 0x00, 0x00, 0x00, 0x00, 0x00, 0x1C, 0x36, 0x66, 0x6E, 0x72, 0x72, 0x26, 0x1C, 0x00, 0x00, 0x00 }, /* 48 '0' */
  { 0x00, 0x00, 0x00, 0x00, 0x00, 0x18, 0x38, 0x28, 0x08, 0x08, 0x08, 0x08, 0x3E, 0x00, 0x00, 0x00 }, /* 49 '1' */
  { 0x00, 0x00, 0x00, 0x00, 0x00, 0x3C, 0x26, 0x06, 0x04, 0x0C, 0x18, 0x30, 0x3E, 0x00, 0x00, 0x00 }, /* 50 '2' */
  { 0x00, 0x00, 0x00, 0x00, 0x00, 0x3C, 0x06, 0x04, 0x1C, 0x06, 0x06, 0x06, 0x3C, 0x00, 0x00, 0x00 }, /* 51 '3' */
  { 0x00, 0x00, 0x00, 0x00, 0x00, 0x0C, 0x1C, 0x14, 0x34, 0x64, 0x7E, 0x04, 0x04, 0x00, 0x00, 0x00 }, /* 52 '4' */
  { 0x00, 0x00, 0x00, 0x00, 0x00, 0x3E, 0x20, 0x20, 0x3C, 0x06, 0x06, 0x06, 0x3C, 0x00, 0x00, 0x00 }, /* 53 '5' */
  { 0x00, 0x00, 0x00, 0x00, 0x00, 0x1E, 0x30, 0x20, 0x3C, 0x36, 0x22, 0x36, 0x1C, 0x00, 0x00, 0x00 }, /* 54 '6' */
  { 0x00, 0x00, 0x00, 0x00, 0x00, 0x3E, 0x06, 0x04, 0x0C, 0x08, 0x18, 0x18, 0x30, 0x00, 0x00, 0x00 }, /* 55 '7' */
  { 0x00, 0x00, 0x00, 0x00, 0x00, 0x1C, 0x26, 0x36, 0x3C, 0x3E, 0x26, 0x26, 0x3C, 0x00, 0x00, 0x00 }, /* 56 '8' */
  { 0x00, 0x00, 0x00, 0x00, 0x00, 0x3C, 0x26, 0x66, 0x26, 0x3E, 0x06, 0x04, 0x38, 0x00, 0x00, 0x00 }, /* 57 '9' */
  { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x18, 0x18, 0x00, 0x00, 0x18, 0x18, 0x00, 0x00, 0x00 }, /* 58 ':' */
  { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x18, 0x18, 0x00, 0x00, 0x18, 0x0C, 0x08, 0x30, 0x00 }, /* 59 ';' */
  { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x04, 0x0C, 0x18, 0x30, 0x18, 0x0C, 0x04, 0x00, 0x00, 0x00 }, /* 60 '<' */
  { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x3E, 0x00, 0x3E, 0x00, 0x00, 0x00, 0x00, 0x00 }, /* 61 '=' */
  { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x10, 0x18, 0x0C, 0x06, 0x0C, 0x18, 0x10, 0x00, 0x00, 0x00 }, /* 62 '>' */
  { 0x00, 0x00, 0x00, 0x00, 0x00, 0x18, 0x0C, 0x06, 0x06, 0x1C, 0x00, 0x18, 0x18, 0x00, 0x00, 0x00 }, /* 63 '?' */
  { 0x00, 0x00, 0x00, 0x00, 0x00, 0x1C, 0x32, 0x22, 0x7F, 0x77, 0x7E, 0x5E, 0x60, 0x20, 0x3C, 0x00 }, /* 64 '@' */
  { 0x00, 0x00, 0x00, 0x00, 0x00, 0x1C, 0x1C, 0x14, 0x34, 0x26, 0x3E, 0x62, 0x63, 0x00, 0x00, 0x00 }, /* 65 'A' */
  { 0x00, 0x00, 0x00, 0x00, 0x00, 0x3C, 0x26, 0x26, 0x3C, 0x26, 0x26, 0x26, 0x3C, 0x00, 0x00, 0x00 }, /* 66 'B' */
  { 0x00, 0x00, 0x00, 0x00, 0x00, 0x1E, 0x30, 0x20, 0x20, 0x60, 0x20, 0x30, 0x1E, 0x00, 0x00, 0x00 }, /* 67 'C' */
  { 0x00, 0x00, 0x00, 0x00, 0x00, 0x7C, 0x66, 0x66, 0x62, 0x62, 0x66, 0x66, 0x7C, 0x00, 0x00, 0x00 }, /* 68 'D' */
  { 0x00, 0x00, 0x00, 0x00, 0x00, 0x3E, 0x30, 0x30, 0x3E, 0x30, 0x30, 0x30, 0x3E, 0x00, 0x00, 0x00 }, /* 69 'E' */
  { 0x00, 0x00, 0x00, 0x00, 0x00, 0x3E, 0x30, 0x30, 0x30, 0x3E, 0x30, 0x30, 0x30, 0x00, 0x00, 0x00 }, /* 70 'F' */
  { 0x00, 0x00, 0x00, 0x00, 0x00, 0x1C, 0x32, 0x60, 0x60, 0x6E, 0x62, 0x32, 0x1E, 0x00, 0x00, 0x00 }, /* 71 'G' */
  { 0x00, 0x00, 0x00, 0x00, 0x00, 0x62, 0x62, 0x62, 0x7E, 0x62, 0x62, 0x62, 0x62, 0x00, 0x00, 0x00 }, /* 72 'H' */
  { 0x00, 0x00, 0x00, 0x00, 0x00, 0x3E, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x3E, 0x00, 0x00, 0x00 }, /* 73 'I' */
  { 0x00, 0x00, 0x00, 0x00, 0x00, 0x3C, 0x04, 0x04, 0x04, 0x04, 0x04, 0x2C, 0x38, 0x00, 0x00, 0x00 }, /* 74 'J' */
  { 0x00, 0x00, 0x00, 0x00, 0x00, 0x26, 0x24, 0x2C, 0x38, 0x38, 0x2C, 0x24, 0x26, 0x00, 0x00, 0x00 }, /* 75 'K' */
  { 0x00, 0x00, 0x00, 0x00, 0x00, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x3E, 0x00, 0x00, 0x00 }, /* 76 'L' */
  { 0x00, 0x00, 0x00, 0x00, 0x00, 0x26, 0x76, 0x76, 0x7A, 0x7A, 0x6A, 0x62, 0x62, 0x00, 0x00, 0x00 }, /* 77 'M' */
  { 0x00, 0x00, 0x00, 0x00, 0x00, 0x72, 0x72, 0x72, 0x7A, 0x6E, 0x6E, 0x66, 0x66, 0x00, 0x00, 0x00 }, /* 78 'N' */
  { 0x00, 0x00, 0x00, 0x00, 0x00, 0x1C, 0x26, 0x62, 0x62, 0x62, 0x62, 0x26, 0x3C, 0x00, 0x00, 0x00 }, /* 79 'O' */
  { 0x00, 0x00, 0x00, 0x00, 0x00, 0x3C, 0x26, 0x26, 0x26, 0x3C, 0x20, 0x20, 0x20, 0x00, 0x00, 0x00 }, /* 80 'P' */
  { 0x00, 0x00, 0x00, 0x00, 0x00, 0x1C, 0x26, 0x62, 0x62, 0x62, 0x62, 0x26, 0x3C, 0x08, 0x0E, 0x00 }, /* 81 'Q' */
  { 0x00, 0x00, 0x00, 0x00, 0x00, 0x3C, 0x26, 0x26, 0x26, 0x3C, 0x2C, 0x26, 0x26, 0x00, 0x00, 0x00 }, /* 82 'R' */
  { 0x00, 0x00, 0x00, 0x00, 0x00, 0x1C, 0x30, 0x30, 0x3C, 0x0E, 0x06, 0x06, 0x3C, 0x00, 0x00, 0x00 }, /* 83 'S' */
  { 0x00, 0x00, 0x00, 0x00, 0x00, 0x7E, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x00, 0x00, 0x00 }, /* 84 'T' */
  { 0x00, 0x00, 0x00, 0x00, 0x00, 0x62, 0x62, 0x62, 0x62, 0x62, 0x62, 0x26, 0x3C, 0x00, 0x00, 0x00 }, /* 85 'U' */
  { 0x00, 0x00, 0x00, 0x00, 0x00, 0x63, 0x62, 0x26, 0x36, 0x34, 0x1C, 0x1C, 0x18, 0x00, 0x00, 0x00 }, /* 86 'V' */
  { 0x00, 0x00, 0x00, 0x00, 0x00, 0x62, 0x62, 0x6A, 0x7A, 0x7A, 0x76, 0x76, 0x26, 0x00, 0x00, 0x00 }, /* 87 'W' */
  { 0x00, 0x00, 0x00, 0x00, 0x00, 0x66, 0x36, 0x1C, 0x18, 0x1C, 0x3C, 0x36, 0x66, 0x00, 0x00, 0x00 }, /* 88 'X' */
  { 0x00, 0x00, 0x00, 0x00, 0x00, 0x62, 0x26, 0x34, 0x1C, 0x18, 0x18, 0x18, 0x18, 0x00, 0x00, 0x00 }, /* 89 'Y' */
  { 0x00, 0x00, 0x00, 0x00, 0x00, 0x3E, 0x04, 0x0C, 0x08, 0x18, 0x10, 0x30, 0x3E, 0x00, 0x00, 0x00 }, /* 90 'Z' */
  { 0x00, 0x00, 0x00, 0x00, 0x1C, 0x10, 0x10, 0x10, 0x10, 0x10, 0x10, 0x10, 0x10, 0x10, 0x1C, 0x00 }, /* 91 '[' */
  { 0x00, 0x00, 0x00, 0x00, 0x00, 0x20, 0x30, 0x10, 0x18, 0x08, 0x0C, 0x04, 0x06, 0x06, 0x00, 0x00 }, /* 92 '\' */
  { 0x00, 0x00, 0x00, 0x00, 0x3C, 0x0C, 0x0C, 0x0C, 0x0C, 0x0C, 0x0C, 0x0C, 0x0C, 0x0C, 0x3C, 0x00 }, /* 93 ']' */
  { 0x00, 0x00, 0x00, 0x00, 0x00, 0x18, 0x1C, 0x34, 0x26, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 }, /* 94 '^' */
  { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x7F, 0x00 }, /* 95 '_' */
  { 0x00, 0x00, 0x00, 0x00, 0x30, 0x18, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 }, /* 96 '`' */
  { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x3C, 0x06, 0x1E, 0x26, 0x26, 0x3E, 0x00, 0x00, 0x00 }, /* 97 'a' */
  { 0x00, 0x00, 0x00, 0x00, 0x00, 0x20, 0x20, 0x3C, 0x36, 0x22, 0x22, 0x26, 0x3C, 0x00, 0x00, 0x00 }, /* 98 'b' */
  { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x1E, 0x30, 0x20, 0x20, 0x30, 0x1E, 0x00, 0x00, 0x00 }, /* 99 'c' */
  { 0x00, 0x00, 0x00, 0x00, 0x00, 0x06, 0x06, 0x1E, 0x36, 0x66, 0x66, 0x26, 0x3E, 0x00, 0x00, 0x00 }, /* 100 'd' */
  { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x1C, 0x26, 0x3E, 0x20, 0x30, 0x1E, 0x00, 0x00, 0x00 }, /* 101 'e' */
  { 0x00, 0x00, 0x00, 0x00, 0x00, 0x0E, 0x18, 0x18, 0x7E, 0x18, 0x18, 0x18, 0x18, 0x00, 0x00, 0x00 }, /* 102 'f' */
  { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x1E, 0x26, 0x26, 0x3C, 0x20, 0x3E, 0x66, 0x3C, 0x00 }, /* 103 'g' */
  { 0x00, 0x00, 0x00, 0x00, 0x00, 0x20, 0x20, 0x3C, 0x36, 0x26, 0x26, 0x26, 0x26, 0x00, 0x00, 0x00 }, /* 104 'h' */
  { 0x00, 0x00, 0x00, 0x00, 0x08, 0x08, 0x00, 0x38, 0x08, 0x08, 0x08, 0x08, 0x3E, 0x00, 0x00, 0x00 }, /* 105 'i' */
  { 0x00, 0x00, 0x00, 0x00, 0x04, 0x04, 0x00, 0x3C, 0x04, 0x04, 0x04, 0x04, 0x04, 0x0C, 0x38, 0x00 }, /* 106 'j' */
  { 0x00, 0x00, 0x00, 0x00, 0x00, 0x20, 0x20, 0x26, 0x2C, 0x38, 0x38, 0x2C, 0x26, 0x00, 0x00, 0x00 }, /* 107 'k' */
  { 0x00, 0x00, 0x00, 0x00, 0x00, 0x38, 0x08, 0x08, 0x08, 0x08, 0x08, 0x08, 0x3E, 0x00, 0x00, 0x00 }, /* 108 'l' */
  { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x7E, 0x6A, 0x6A, 0x6A, 0x6A, 0x6A, 0x00, 0x00, 0x00 }, /* 109 'm' */
  { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x3C, 0x36, 0x26, 0x26, 0x26, 0x26, 0x00, 0x00, 0x00 }, /* 110 'n' */
  { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x1C, 0x26, 0x62, 0x62, 0x26, 0x3C, 0x00, 0x00, 0x00 }, /* 111 'o' */
  { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x3C, 0x36, 0x22, 0x22, 0x26, 0x3C, 0x20, 0x20, 0x00 }, /* 112 'p' */
  { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x1E, 0x36, 0x66, 0x66, 0x26, 0x3E, 0x06, 0x06, 0x00 }, /* 113 'q' */
  { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x3E, 0x36, 0x30, 0x30, 0x30, 0x30, 0x00, 0x00, 0x00 }, /* 114 'r' */
  { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x1C, 0x30, 0x38, 0x0E, 0x06, 0x3C, 0x00, 0x00, 0x00 }, /* 115 's' */
  { 0x00, 0x00, 0x00, 0x00, 0x00, 0x10, 0x10, 0x7E, 0x10, 0x10, 0x10, 0x18, 0x0E, 0x00, 0x00, 0x00 }, /* 116 't' */
  { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x26, 0x26, 0x26, 0x26, 0x26, 0x3E, 0x00, 0x00, 0x00 }, /* 117 'u' */
  { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x62, 0x26, 0x36, 0x34, 0x1C, 0x18, 0x00, 0x00, 0x00 }, /* 118 'v' */
  { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x63, 0x62, 0x6A, 0x7A, 0x36, 0x36, 0x00, 0x00, 0x00 }, /* 119 'w' */
  { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x26, 0x34, 0x1C, 0x1C, 0x34, 0x66, 0x00, 0x00, 0x00 }, /* 120 'x' */
  { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x62, 0x26, 0x34, 0x34, 0x1C, 0x18, 0x18, 0x70, 0x00 }, /* 121 'y' */
  { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x3E, 0x0C, 0x08, 0x18, 0x10, 0x3E, 0x00, 0x00, 0x00 }, /* 122 'z' */
  { 0x00, 0x00, 0x00, 0x00, 0x0C, 0x08, 0x18, 0x18, 0x18, 0x30, 0x18, 0x18, 0x18, 0x18, 0x0C, 0x00 }, /* 123 '{' */
  { 0x00, 0x00, 0x00, 0x08, 0x08, 0x08, 0x08, 0x08, 0x08, 0x08, 0x08, 0x08, 0x08, 0x08, 0x08, 0x00 }, /* 124 '|' */
  { 0x00, 0x00, 0x00, 0x00, 0x30, 0x08, 0x08, 0x08, 0x08, 0x0E, 0x08, 0x08, 0x08, 0x08, 0x30, 0x00 }, /* 125 '}' */
  { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x32, 0x6A, 0x6E, 0x00, 0x00, 0x00, 0x00, 0x00 }, /* 126 '~' */
};

/* Send one command byte to the SSD1306. Returns 1 on success. */
static uint8_t OLED_WriteCmd(uint8_t cmd)
{
  uint8_t buf[2];
  buf[0] = OLED_CTRL_CMD;
  buf[1] = cmd;
  return (HAL_I2C_Master_Transmit(&hi2c1, oled_addr, buf, 2u, OLED_TIMEOUT) == HAL_OK) ? 1u : 0u;
}

/* Free a bus that a slave, or a previously aborted transfer, keeps busy:
 * clock SCL nine times with SDA released, emit a STOP, then restore I2C1. */
static void I2C1_BusRecover(void)
{
  GPIO_InitTypeDef gpio = {0};
  uint8_t i;

  HAL_I2C_DeInit(&hi2c1);

  gpio.Pin = GPIO_PIN_6 | GPIO_PIN_7;
  gpio.Mode = GPIO_MODE_OUTPUT_OD;
  gpio.Pull = GPIO_NOPULL;
  gpio.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(GPIOB, &gpio);

  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_7, GPIO_PIN_SET);   /* SDA released */
  for (i = 0; i < 9u; i++)
  {
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_6, GPIO_PIN_RESET);
    HAL_Delay(1u);
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_6, GPIO_PIN_SET);
    HAL_Delay(1u);
  }
  /* STOP condition: SDA low, SCL high, then SDA high. */
  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_7, GPIO_PIN_RESET);
  HAL_Delay(1u);
  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_6, GPIO_PIN_SET);
  HAL_Delay(1u);
  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_7, GPIO_PIN_SET);
  HAL_Delay(1u);

  MX_I2C1_Init();   /* re-enable the peripheral and its PB6/PB7 AF pins */
}

/* Probe every legal 7-bit address and remember the ones that acknowledge. */
static uint8_t I2C1_Scan(void)
{
  uint8_t addr;
  uint8_t count = 0u;

  i2c_dev_count = 0u;
  for (addr = 0x08u; addr <= 0x77u; addr++)
  {
    if (HAL_I2C_IsDeviceReady(&hi2c1, (uint16_t)(addr << 1), 2u, 20u) == HAL_OK)
    {
      if (count < (uint8_t)sizeof(i2c_ack_map))
      {
        i2c_ack_map[count] = addr;
        count++;
      }
    }
  }
  i2c_dev_count = count;
  return count;
}

/* Prefer 0x3C/0x3D (the two SSD1306 strapping options), else the first hit. */
static uint16_t I2C1_PickOledAddress(void)
{
  uint8_t i;

  for (i = 0; i < i2c_dev_count && i < (uint8_t)sizeof(i2c_ack_map); i++)
  {
    if (i2c_ack_map[i] == 0x3Cu || i2c_ack_map[i] == 0x3Du)
    {
      return (uint16_t)(i2c_ack_map[i] << 1);
    }
  }
  if (i2c_dev_count > 0u)
  {
    return (uint16_t)(i2c_ack_map[0] << 1);
  }
  return (uint16_t)(0x3Cu << 1);
}

/* SSD1306 power-up sequence for a 128x64 panel. Returns 1 when every command
 * was acknowledged, which also proves the panel is wired and powered. */
static uint8_t OLED_Init(void)
{
  static const uint8_t init_seq[] = {
    0xAE,         /* display off */
    0xD5, 0x80,   /* clock divide ratio / oscillator frequency */
    0xA8, 0x3F,   /* multiplex ratio = 64 */
    0xD3, 0x00,   /* display offset = 0 */
    0x40,         /* start line = 0 */
    0x8D, 0x14,   /* charge pump enabled */
    0x20, 0x00,   /* horizontal addressing mode */
    0xA1,         /* segment remap: column 127 -> SEG0 */
    0xC8,         /* COM scan direction remapped */
    0xDA, 0x12,   /* COM pins: alternative configuration */
    0x81, 0xCF,   /* contrast */
    0xD9, 0xF1,   /* pre-charge period */
    0xDB, 0x40,   /* VCOMH deselect level */
    0xA4,         /* display follows RAM content */
    0xA6,         /* normal (not inverted) */
    0xAF          /* display on */
  };
  uint16_t i;
  for (i = 0; i < sizeof(init_seq); i++)
  {
    if (!OLED_WriteCmd(init_seq[i]))
    {
      return 0u;
    }
  }
  return 1u;
}

static void OLED_ClearBuffer(void)
{
  uint8_t page, col;
  for (page = 0; page < OLED_PAGES; page++)
  {
    for (col = 0; col < OLED_WIDTH; col++)
    {
      oled_buffer[page][col] = 0x00u;
    }
  }
}

/* Draw one 8x16 character with its top-left corner at (x, page*8). */
static void OLED_DrawChar(uint8_t x, uint8_t page, char c)
{
  const uint8_t *glyph;
  uint8_t row, bit, px, target_page;

  if (c < 32 || c > 126)
  {
    c = '?';
  }
  glyph = font8x16[(uint8_t)c - 32u];

  for (row = 0; row < 16u; row++)
  {
    target_page = page + (row >> 3);
    if (target_page >= OLED_PAGES)
    {
      break;
    }
    for (bit = 0; bit < 8u; bit++)
    {
      px = x + bit;
      if (px >= OLED_WIDTH)
      {
        break;
      }
      if (glyph[row] & (0x80u >> bit))
      {
        oled_buffer[target_page][px] |= (uint8_t)(1u << (row & 7u));
      }
    }
  }
}

/* Draw a NUL terminated string starting at (x, page*8). */
static void OLED_DrawString(uint8_t x, uint8_t page, const char *text)
{
  while (*text != '\0')
  {
    OLED_DrawChar(x, page, *text);
    text++;
    x = (uint8_t)(x + 8u);
    if ((uint16_t)x + 8u > OLED_WIDTH)
    {
      break;
    }
  }
}

/* Push the whole frame buffer to the panel. Returns 1 on success. */
static uint8_t OLED_Flush(void)
{
  uint8_t page, cmd;
  uint16_t col;

  for (page = 0; page < OLED_PAGES; page++)
  {
    cmd = (uint8_t)(0xB0u | page);        /* page start address */
    if (!OLED_WriteCmd(cmd)) { return 0u; }
    if (!OLED_WriteCmd(0x00u)) { return 0u; }   /* lower column start = 0 */
    if (!OLED_WriteCmd(0x10u)) { return 0u; }   /* upper column start = 0 */

    oled_tx[0] = OLED_CTRL_DATA;
    for (col = 0; col < OLED_WIDTH; col++)
    {
      oled_tx[col + 1u] = oled_buffer[page][col];
    }
    if (HAL_I2C_Master_Transmit(&hi2c1, oled_addr, oled_tx,
                                (uint16_t)(OLED_WIDTH + 1u), OLED_TIMEOUT) != HAL_OK)
    {
      return 0u;
    }
  }
  return 1u;
}

/* ==========================================================================
 * MPU6050 driver (I2C1, same bus as the OLED: PB6 = SCL, PB7 = SDA)
 * AD0 is tied to GND, so the 7-bit address is 0x68.
 * ========================================================================== */

typedef struct
{
  int16_t ax;
  int16_t ay;
  int16_t az;
  int16_t gx;
  int16_t gy;
  int16_t gz;
} MPU6050_Data;

/* Draw four 16-pixel-high lines (pages 0, 2, 4, 6) and push them. */
static void OLED_ShowLines(const char *line0, const char *line1,
                           const char *line2, const char *line3)
{
  if (oled_state != 1u)
  {
    return;
  }

  OLED_ClearBuffer();
  if (line0 != NULL) { OLED_DrawString(0u, 0u, line0); }
  if (line1 != NULL) { OLED_DrawString(0u, 2u, line1); }
  if (line2 != NULL) { OLED_DrawString(0u, 4u, line2); }
  if (line3 != NULL) { OLED_DrawString(0u, 6u, line3); }
  oled_state = OLED_Flush() ? 1u : 0xE1u;
}

static uint8_t MPU_ReadRegs(uint8_t reg, uint8_t *buf, uint16_t len)
{
  return (HAL_I2C_Mem_Read(&hi2c1, mpu_addr, reg, I2C_MEMADD_SIZE_8BIT,
                           buf, len, MPU6050_TIMEOUT) == HAL_OK) ? 1u : 0u;
}

static uint8_t MPU_WriteReg(uint8_t reg, uint8_t value)
{
  uint8_t data = value;
  return (HAL_I2C_Mem_Write(&hi2c1, mpu_addr, reg, I2C_MEMADD_SIZE_8BIT,
                            &data, 1u, MPU6050_TIMEOUT) == HAL_OK) ? 1u : 0u;
}

/* Wake the sensor, set a 100 Hz sample rate and the +/-2 g / +/-500 deg/s
 * ranges.  The WHO_AM_I check catches a missing or mis-addressed module. */
static uint8_t MPU_Init(void)
{
  uint8_t who = 0u;

  mpu_state = 0xE0u;

  /* AD0 is often left floating on break-out boards.  Probe 0x68 first, then
   * 0x69, so both strapping options work without editing the source. */
  mpu_addr = MPU6050_ADDR_68;
  if (!MPU_ReadRegs(MPU6050_REG_WHO_AM_I, &who, 1u))
  {
    mpu_addr = MPU6050_ADDR_69;
    if (!MPU_ReadRegs(MPU6050_REG_WHO_AM_I, &who, 1u))
    {
      return 0u;
    }
  }
  if ((who != 0x68u) && (who != 0x70u))
  {
    mpu_state = 0xE1u;
    return 0u;
  }

  if (!MPU_WriteReg(MPU6050_REG_PWR_MGMT_1, 0x80u))   /* device reset */
  {
    mpu_state = 0xE2u;
    return 0u;
  }
  HAL_Delay(100u);

  if (!MPU_WriteReg(MPU6050_REG_PWR_MGMT_1, 0x00u))   /* wake up */
  {
    mpu_state = 0xE2u;
    return 0u;
  }
  HAL_Delay(50u);

  if (!MPU_WriteReg(MPU6050_REG_SMPLRT_DIV, 0x09u) || /* 1 kHz / 10 = 100 Hz */
      !MPU_WriteReg(MPU6050_REG_CONFIG, 0x04u) ||      /* DLPF ~21 Hz */
      !MPU_WriteReg(MPU6050_REG_GYRO_CONFIG, 0x08u) || /* +/-500 deg/s */
      !MPU_WriteReg(MPU6050_REG_ACCEL_CONFIG, 0x00u))  /* +/-2 g */
  {
    mpu_state = 0xE2u;
    return 0u;
  }

  mpu_state = 1u;
  return 1u;
}

static uint8_t MPU_Read(MPU6050_Data *d)
{
  uint8_t b[14];

  if (!MPU_ReadRegs(MPU6050_REG_ACCEL_XOUT_H, b, 14u))
  {
    return 0u;
  }

  d->ax = (int16_t)(((uint16_t)b[0] << 8) | (uint16_t)b[1]);
  d->ay = (int16_t)(((uint16_t)b[2] << 8) | (uint16_t)b[3]);
  d->az = (int16_t)(((uint16_t)b[4] << 8) | (uint16_t)b[5]);
  d->gx = (int16_t)(((uint16_t)b[8] << 8) | (uint16_t)b[9]);
  d->gy = (int16_t)(((uint16_t)b[10] << 8) | (uint16_t)b[11]);
  d->gz = (int16_t)(((uint16_t)b[12] << 8) | (uint16_t)b[13]);
  mpu_sample_count++;
  return 1u;
}

/* Average the gyro while the board is still; this removes the zero-rate
 * offset that would otherwise integrate into a large angle drift. */
static uint8_t MPU_CalibrateGyro(void)
{
  int32_t sx = 0;
  int32_t sy = 0;
  int32_t sz = 0;
  MPU6050_Data d;
  uint16_t i;

  for (i = 0u; i < MPU6050_CALIB_SAMPLES; i++)
  {
    if (!MPU_Read(&d))
    {
      mpu_state = 0xE4u;
      return 0u;
    }
    sx += d.gx;
    sy += d.gy;
    sz += d.gz;
    HAL_Delay(5u);
  }

  mpu_gyro_bias_x = ((float)sx / (float)MPU6050_CALIB_SAMPLES) / MPU6050_GYRO_SCALE;
  mpu_gyro_bias_y = ((float)sy / (float)MPU6050_CALIB_SAMPLES) / MPU6050_GYRO_SCALE;
  mpu_gyro_bias_z = ((float)sz / (float)MPU6050_CALIB_SAMPLES) / MPU6050_GYRO_SCALE;
  mpu_first_sample = 1u;
  return 1u;
}

static const char *MPU_StateText(void)
{
  switch (mpu_state)
  {
    case 1u:    return "OK";
    case 0xE0u: return "NOT FOUND";
    case 0xE1u: return "WHO_AM_I";
    case 0xE2u: return "INIT FAIL";
    case 0xE3u: return "READ FAIL";
    case 0xE4u: return "CAL FAIL";
    default:    return "ERROR";
  }
}

/* Complementary filter:
 *   angle = alpha * (angle + gyro * dt) + (1 - alpha) * accel_angle
 * The accelerometer is trusted over the long term, the gyro over the short
 * term.  Roll is around X, pitch around Y.  Yaw is not estimated because
 * there is no magnetometer. */
static uint8_t MPU_UpdateAngles(float dt)
{
  MPU6050_Data d;
  float ax;
  float ay;
  float az;
  float gx;
  float gy;
  float gz;
  float roll_acc;
  float pitch_acc;

  if (!MPU_Read(&d))
  {
    mpu_state = 0xE3u;
    return 0u;
  }

  mpu_ax = d.ax;
  mpu_ay = d.ay;
  mpu_az = d.az;
  mpu_gx = d.gx;
  mpu_gy = d.gy;
  mpu_gz = d.gz;

  ax = (float)d.ax / MPU6050_ACCEL_SCALE;
  ay = (float)d.ay / MPU6050_ACCEL_SCALE;
  az = (float)d.az / MPU6050_ACCEL_SCALE;

  gx = ((float)d.gx / MPU6050_GYRO_SCALE) - mpu_gyro_bias_x;
  gy = ((float)d.gy / MPU6050_GYRO_SCALE) - mpu_gyro_bias_y;
  gz = ((float)d.gz / MPU6050_GYRO_SCALE) - mpu_gyro_bias_z;
  (void)gz;

  /* Compensate the 180-degree mounting flips selected by MOUNT 0..3.
   * This keeps the displayed axes intuitive when the MPU is glued to the
   * underside or the back of the gimbal platform. */
  switch (mpu_mount_mode)
  {
    case 1u:  /* 180 deg about X */
      ay = -ay; az = -az;
      gy = -gy; gz = -gz;
      break;
    case 2u:  /* 180 deg about Y */
      ax = -ax; az = -az;
      gx = -gx; gz = -gz;
      break;
    case 3u:  /* 180 deg about Z */
      ax = -ax; ay = -ay;
      gx = -gx; gy = -gy;
      break;
    default:
      break;
  }

  /* atan2(ay, az): 0 deg with the board flat, +90 deg when Y points down. */
  roll_acc = atan2f(ay, az) * (180.0f / 3.14159265f);
  pitch_acc = atan2f(-ax, sqrtf((ay * ay) + (az * az))) * (180.0f / 3.14159265f);
  mpu_roll_acc_x10 = (int32_t)(roll_acc * 10.0f + ((roll_acc >= 0.0f) ? 0.5f : -0.5f));
  mpu_pitch_acc_x10 = (int32_t)(pitch_acc * 10.0f + ((pitch_acc >= 0.0f) ? 0.5f : -0.5f));

  if (dt <= 0.0f)
  {
    dt = 0.01f;
  }
  if (dt > 0.1f)
  {
    dt = 0.1f;
  }

  if (mpu_first_sample)
  {
    mpu_roll = roll_acc;
    mpu_pitch = pitch_acc;
    mpu_first_sample = 0u;
  }
  else
  {
    mpu_roll = (MPU6050_ALPHA * (mpu_roll + (gx * dt)))
             + ((1.0f - MPU6050_ALPHA) * roll_acc);
    mpu_pitch = (MPU6050_ALPHA * (mpu_pitch + (gy * dt)))
              + ((1.0f - MPU6050_ALPHA) * pitch_acc);
  }

  while (mpu_roll > 180.0f)
  {
    mpu_roll -= 360.0f;
  }
  while (mpu_roll < -180.0f)
  {
    mpu_roll += 360.0f;
  }

  mpu_roll_x10 = (int32_t)(mpu_roll * 10.0f + ((mpu_roll >= 0.0f) ? 0.5f : -0.5f));
  mpu_pitch_x10 = (int32_t)(mpu_pitch * 10.0f + ((mpu_pitch >= 0.0f) ? 0.5f : -0.5f));
  return 1u;
}

/* Format a signed angle with one decimal place, e.g. "Roll : -12.3". */
static void MPU_FormatAngle(char *out, uint16_t out_size, const char *label, float degrees)
{
  int32_t tenths = (int32_t)(degrees * 10.0f + ((degrees >= 0.0f) ? 0.5f : -0.5f));
  int32_t mag = (tenths < 0) ? -tenths : tenths;

  snprintf(out, (size_t)out_size, "%s%s%ld.%ld",
           label, (tenths < 0) ? "-" : "",
           (long)(mag / 10), (long)(mag % 10));
}

/* ==========================================================================
 * Two-axis servo control (TIM2_CH1 / PA0 = pan, TIM2_CH2 / PA1 = tilt)
 * ========================================================================== */

static float ClampFloat(float value, float low, float high)
{
  if (value < low)
  {
    return low;
  }
  if (value > high)
  {
    return high;
  }
  return value;
}

static float Wrap180(float angle)
{
  while (angle > 180.0f)
  {
    angle -= 360.0f;
  }
  while (angle < -180.0f)
  {
    angle += 360.0f;
  }
  return angle;
}

static float MPU_RollRelative(void)
{
  return Wrap180(mpu_roll - mpu_roll_zero);
}

static float MPU_PitchRelative(void)
{
  return mpu_pitch - mpu_pitch_zero;
}

static uint16_t Servo_AngleToPulse(float degrees, float trim, uint8_t invert)
{
  float d = ClampFloat(degrees + trim, SERVO_ANGLE_MIN, SERVO_ANGLE_MAX);

  if (invert != 0u)
  {
    d = SERVO_ANGLE_MAX - d;
  }
  return (uint16_t)((float)SERVO_PWM_MIN_US
                    + ((d / SERVO_ANGLE_MAX)
                       * (float)(SERVO_PWM_MAX_US - SERVO_PWM_MIN_US))
                    + 0.5f);
}

static void Servo_Apply(ServoAxis *axis, uint32_t channel, float trim, uint8_t invert)
{
  uint16_t pulse = Servo_AngleToPulse(axis->current_deg, trim, invert);

  /* PID output is an offset in microseconds, added to the normal pitch CCR
   * only.  When PID is disabled the base remote-control pulse is unchanged. */
  if ((channel == TIM_CHANNEL_2) && (PID_IsEnabled() != 0u))
  {
    int32_t adjusted = (int32_t)pulse + (int32_t)PID_GetOutput();

    if (adjusted < (int32_t)SERVO_PWM_MIN_US)
    {
      adjusted = (int32_t)SERVO_PWM_MIN_US;
    }
    else if (adjusted > (int32_t)SERVO_PWM_MAX_US)
    {
      adjusted = (int32_t)SERVO_PWM_MAX_US;
    }
    pulse = (uint16_t)adjusted;
  }

  axis->pulse_us = pulse;
  __HAL_TIM_SET_COMPARE(&htim2, channel, axis->pulse_us);
}

static void Servo_SetPan(float degrees)
{
  sweep_enabled = 0u;
  servo_pan.target_deg = ClampFloat(degrees, SERVO_PAN_MIN_DEG, SERVO_PAN_MAX_DEG);
}

static void Servo_SetTilt(float degrees)
{
  sweep_enabled = 0u;
  servo_tilt.target_deg = ClampFloat(degrees, SERVO_TILT_MIN_DEG, SERVO_TILT_MAX_DEG);
}

static void Servo_Stop(void)
{
  sweep_enabled = 0u;
  servo_pan.target_deg = servo_pan.current_deg;
  servo_tilt.target_deg = servo_tilt.current_deg;
}

/* Advance both axes toward their targets at a limited angular speed. */
static void Servo_Update(void)
{
  uint32_t now = HAL_GetTick();
  float dt;
  float step;

  if ((now - servo_tick) < SERVO_UPDATE_MS)
  {
    return;
  }

  dt = (float)(now - servo_tick) / 1000.0f;
  servo_tick = now;
  if (dt > 0.05f)
  {
    dt = 0.05f;
  }
  step = servo_speed_dps * dt;

  if (servo_pan.current_deg < servo_pan.target_deg)
  {
    servo_pan.current_deg += step;
    if (servo_pan.current_deg > servo_pan.target_deg)
    {
      servo_pan.current_deg = servo_pan.target_deg;
    }
  }
  else if (servo_pan.current_deg > servo_pan.target_deg)
  {
    servo_pan.current_deg -= step;
    if (servo_pan.current_deg < servo_pan.target_deg)
    {
      servo_pan.current_deg = servo_pan.target_deg;
    }
  }

  if (servo_tilt.current_deg < servo_tilt.target_deg)
  {
    servo_tilt.current_deg += step;
    if (servo_tilt.current_deg > servo_tilt.target_deg)
    {
      servo_tilt.current_deg = servo_tilt.target_deg;
    }
  }
  else if (servo_tilt.current_deg > servo_tilt.target_deg)
  {
    servo_tilt.current_deg -= step;
    if (servo_tilt.current_deg < servo_tilt.target_deg)
    {
      servo_tilt.current_deg = servo_tilt.target_deg;
    }
  }

  Servo_Apply(&servo_pan, TIM_CHANNEL_1, SERVO_PAN_TRIM_DEG, SERVO_PAN_INVERT);
  Servo_Apply(&servo_tilt, TIM_CHANNEL_2, SERVO_TILT_TRIM_DEG, SERVO_TILT_INVERT);
}

/* A rectangular demo path, useful for the video / lab demonstration. */
static void Servo_SweepTask(void)
{
  static const float pan_path[4]  = { 35.0f, 145.0f, 145.0f, 35.0f };
  static const float tilt_path[4] = { 55.0f,  55.0f, 125.0f, 125.0f };
  uint32_t now = HAL_GetTick();

  if ((sweep_enabled == 0u) || ((now - sweep_tick) < 1800u))
  {
    return;
  }

  sweep_tick = now;
  servo_pan.target_deg = pan_path[sweep_phase];
  servo_tilt.target_deg = tilt_path[sweep_phase];
  sweep_phase = (uint8_t)((sweep_phase + 1u) & 3u);
}

/* ==========================================================================
 * UART command interface
 * ========================================================================== */

static uint8_t TextEqualNoCase(const char *a, const char *b)
{
  while ((*a != '\0') && (*b != '\0'))
  {
    if (toupper((unsigned char)*a) != toupper((unsigned char)*b))
    {
      return 0u;
    }
    a++;
    b++;
  }
  return ((*a == '\0') && (*b == '\0')) ? 1u : 0u;
}

static uint8_t ParseFloatArg(const char *text, float *value)
{
  char *end;
  float parsed;

  if ((text == NULL) || (*text == '\0'))
  {
    return 0u;
  }

  parsed = strtof(text, &end);
  if (end == text)
  {
    return 0u;
  }
  while ((*end == ' ') || (*end == '\t'))
  {
    end++;
  }
  if (*end != '\0')
  {
    return 0u;
  }
  if (!isfinite(parsed))
  {
    return 0u;
  }

  *value = parsed;
  return 1u;
}

/* Returns 1/0 for on/off, 0xFF for an unrecognised word. */
static uint8_t ParseSwitch(const char *text)
{
  if ((TextEqualNoCase(text, "ON") != 0u) || (TextEqualNoCase(text, "1") != 0u)
      || (TextEqualNoCase(text, "TRUE") != 0u) || (TextEqualNoCase(text, "YES") != 0u))
  {
    return 1u;
  }
  if ((TextEqualNoCase(text, "OFF") != 0u) || (TextEqualNoCase(text, "0") != 0u)
      || (TextEqualNoCase(text, "FALSE") != 0u) || (TextEqualNoCase(text, "NO") != 0u))
  {
    return 0u;
  }
  return 0xFFu;
}

static void UART_PrintHelp(void)
{
  printf("\r\n=== STM32F103 dual-axis gimbal ===\r\n");
  printf("W/S: Pitch +-%d deg   A/D: Yaw +-%d deg (single key)\r\n",
         (int)KEY_STEP_DEG, (int)KEY_STEP_DEG);
  printf("1: PID ON target -30.0   2: PID target 0.0   0: PID OFF\r\n");
  printf("Text commands need ':' prefix and Enter, e.g. :STATUS\r\n");
  printf(":PAN <deg>      pan target (%d..%d)\r\n",
         (int)SERVO_PAN_MIN_DEG, (int)SERVO_PAN_MAX_DEG);
  printf(":TILT <deg>     tilt target (%d..%d)\r\n",
         (int)SERVO_TILT_MIN_DEG, (int)SERVO_TILT_MAX_DEG);
  printf(":MOVE <pan> <tilt>  move both axes\r\n");
  printf(":CENTER         both axes to 90 deg\r\n");
  printf(":STOP           hold the current position\r\n");
  printf(":SWEEP [ON|OFF] automatic rectangular path\r\n");
  printf(":SPEED <dps>    %d..%d deg/s\r\n",
         (int)SERVO_SPEED_MIN_DPS, (int)SERVO_SPEED_MAX_DPS);
  printf(":ZERO [RESET]   capture/clear the angle reference\r\n");
  printf(":MOUNT <0..3>   MPU mounting compensation\r\n");
  printf(":CAL            recalibrate gyro (keep still)\r\n");
  printf(":STREAM ON|OFF  5 Hz DATA output\r\n");
  printf(":STATUS / :RAW / :PING / :VER / :HELP\r\n");
}

static void UART_PrintStatus(void)
{
  char roll[12];
  char pitch[12];
  char pan[12];
  char tilt[12];
  char pid_target[12];

  MPU_FormatAngle(roll, sizeof(roll), "", MPU_RollRelative());
  MPU_FormatAngle(pitch, sizeof(pitch), "", MPU_PitchRelative());
  MPU_FormatAngle(pan, sizeof(pan), "", servo_pan.current_deg);
  MPU_FormatAngle(tilt, sizeof(tilt), "", servo_tilt.current_deg);
  MPU_FormatAngle(pid_target, sizeof(pid_target), "", PID_GetTarget());

  printf("STATUS fw=%s mpu=%s mount=%u zero=%u roll=%s pitch=%s pan=%s tilt=%s "
         "pus=%u tus=%u speed=%d stream=%u sweep=%u\r\n",
         FW_VERSION, MPU_StateText(), (unsigned)mpu_mount_mode,
         (unsigned)mpu_zero_active, roll, pitch, pan, tilt,
         (unsigned)servo_pan.pulse_us, (unsigned)servo_tilt.pulse_us,
         (int)(servo_speed_dps + 0.5f), (unsigned)stream_enabled,
         (unsigned)sweep_enabled);
  printf("PID en=%u target=%s output=%dus\r\n",
         (unsigned)PID_IsEnabled(), pid_target, (int)PID_GetOutput());
  printf("I2C scan:");
  for (uint8_t k = 0u; (k < i2c_dev_count) && (k < 8u); k++)
  {
    printf(" 0x%02X", (unsigned)i2c_ack_map[k]);
  }
  printf("\r\n");
}

static void UART_PrintRaw(void)
{
  printf("RAW ax=%d ay=%d az=%d gx=%d gy=%d gz=%d ra=%ld pa=%ld\r\n",
         (int)mpu_ax, (int)mpu_ay, (int)mpu_az,
         (int)mpu_gx, (int)mpu_gy, (int)mpu_gz,
         (long)mpu_roll_acc_x10, (long)mpu_pitch_acc_x10);
}

static void UART_PrintData(void)
{
  char roll[12];
  char pitch[12];
  char pan[12];
  char tilt[12];

  MPU_FormatAngle(roll, sizeof(roll), "", MPU_RollRelative());
  MPU_FormatAngle(pitch, sizeof(pitch), "", MPU_PitchRelative());
  MPU_FormatAngle(pan, sizeof(pan), "", servo_pan.current_deg);
  MPU_FormatAngle(tilt, sizeof(tilt), "", servo_tilt.current_deg);

  printf("DATA t=%lu roll=%s pitch=%s pan=%s tilt=%s pus=%u tus=%u\r\n",
         (unsigned long)HAL_GetTick(), roll, pitch, pan, tilt,
         (unsigned)servo_pan.pulse_us, (unsigned)servo_tilt.pulse_us);
}

static void UART_ProcessLine(char *line)
{
  char cmd[16] = {0};
  char arg1[24] = {0};
  char arg2[24] = {0};
  int fields;
  float value1;
  float value2;
  uint8_t sw;

  while ((*line == ' ') || (*line == '\t'))
  {
    line++;
  }
  if (*line == '\0')
  {
    printf("> ");
    return;
  }

  fields = sscanf(line, "%15s %23s %23s", cmd, arg1, arg2);
  if (fields < 1)
  {
    printf("> ");
    return;
  }

  if (TextEqualNoCase(cmd, "HELP") != 0u)
  {
    UART_PrintHelp();
  }
  else if (TextEqualNoCase(cmd, "STATUS") != 0u)
  {
    UART_PrintStatus();
    UART_PrintRaw();
  }
  else if (TextEqualNoCase(cmd, "RAW") != 0u)
  {
    UART_PrintRaw();
  }
  else if (TextEqualNoCase(cmd, "PAN") != 0u)
  {
    if ((fields >= 2) && (ParseFloatArg(arg1, &value1) != 0u))
    {
      Servo_SetPan(value1);
      printf("OK PAN target=%d", (int)(servo_pan.target_deg + 0.5f));
    }
    else
    {
      printf("ERR usage: PAN <deg>");
    }
  }
  else if (TextEqualNoCase(cmd, "TILT") != 0u)
  {
    if ((fields >= 2) && (ParseFloatArg(arg1, &value1) != 0u))
    {
      Servo_SetTilt(value1);
      printf("OK TILT target=%d", (int)(servo_tilt.target_deg + 0.5f));
    }
    else
    {
      printf("ERR usage: TILT <deg>");
    }
  }
  else if (TextEqualNoCase(cmd, "MOVE") != 0u)
  {
    if ((fields >= 3) && (ParseFloatArg(arg1, &value1) != 0u)
        && (ParseFloatArg(arg2, &value2) != 0u))
    {
      Servo_SetPan(value1);
      Servo_SetTilt(value2);
      printf("OK MOVE pan=%d tilt=%d",
             (int)(servo_pan.target_deg + 0.5f),
             (int)(servo_tilt.target_deg + 0.5f));
    }
    else
    {
      printf("ERR usage: MOVE <pan> <tilt>");
    }
  }
  else if (TextEqualNoCase(cmd, "CENTER") != 0u)
  {
    Servo_SetPan(SERVO_CENTER_DEG);
    Servo_SetTilt(SERVO_CENTER_DEG);
    printf("OK CENTER");
  }
  else if (TextEqualNoCase(cmd, "STOP") != 0u)
  {
    Servo_Stop();
    printf("OK STOP");
  }
  else if (TextEqualNoCase(cmd, "SWEEP") != 0u)
  {
    if (fields < 2)
    {
      sw = (sweep_enabled != 0u) ? 0u : 1u;
    }
    else
    {
      sw = ParseSwitch(arg1);
    }

    if (sw == 0xFFu)
    {
      printf("ERR usage: SWEEP [ON|OFF]");
    }
    else if (sw != 0u)
    {
      sweep_enabled = 1u;
      sweep_phase = 0u;
      sweep_tick = HAL_GetTick() - 1800u;
      printf("OK SWEEP ON");
    }
    else
    {
      sweep_enabled = 0u;
      printf("OK SWEEP OFF");
    }
  }
  else if (TextEqualNoCase(cmd, "SPEED") != 0u)
  {
    if ((fields >= 2) && (ParseFloatArg(arg1, &value1) != 0u))
    {
      servo_speed_dps = ClampFloat(value1, SERVO_SPEED_MIN_DPS, SERVO_SPEED_MAX_DPS);
      printf("OK SPEED=%d", (int)(servo_speed_dps + 0.5f));
    }
    else
    {
      printf("ERR usage: SPEED <dps>");
    }
  }
  else if (TextEqualNoCase(cmd, "ZERO") != 0u)
  {
    if ((fields >= 2)
        && ((TextEqualNoCase(arg1, "RESET") != 0u) || (TextEqualNoCase(arg1, "OFF") != 0u)))
    {
      mpu_roll_zero = 0.0f;
      mpu_pitch_zero = 0.0f;
      mpu_zero_active = 0u;
      printf("OK ZERO RESET");
    }
    else if (mpu_state == 1u)
    {
      mpu_roll_zero = mpu_roll;
      mpu_pitch_zero = mpu_pitch;
      mpu_zero_active = 1u;
      printf("OK ZERO captured");
    }
    else
    {
      printf("ERR MPU not ready");
    }
  }
  else if (TextEqualNoCase(cmd, "MOUNT") != 0u)
  {
    char *end = NULL;
    long mode;

    if (fields >= 2)
    {
      mode = strtol(arg1, &end, 10);
    }
    else
    {
      mode = -1;
    }

    if ((end == arg1) || (mode < 0) || (mode > 3))
    {
      printf("ERR usage: MOUNT <0..3>");
    }
    else
    {
      mpu_mount_mode = (uint8_t)mode;
      mpu_first_sample = 1u;
      printf("OK MOUNT=%ld (filter restarted)", mode);
    }
  }
  else if (TextEqualNoCase(cmd, "CAL") != 0u)
  {
    Servo_Stop();
    printf("CAL keep still...");
    if (MPU_CalibrateGyro() != 0u)
    {
      mpu_first_sample = 1u;
      printf("OK");
    }
    else
    {
      printf("ERR calibration failed");
    }
  }
  else if (TextEqualNoCase(cmd, "STREAM") != 0u)
  {
    sw = (fields >= 2) ? ParseSwitch(arg1) : 0xFFu;
    if (sw == 0xFFu)
    {
      printf("ERR usage: STREAM ON|OFF");
    }
    else
    {
      stream_enabled = sw;
      printf("OK STREAM %s", (sw != 0u) ? "ON" : "OFF");
    }
  }
  else if (TextEqualNoCase(cmd, "PING") != 0u)
  {
    printf("PONG");
  }
  else if (TextEqualNoCase(cmd, "VER") != 0u)
  {
    printf("FW %s  STM32F103C8T6  MPU6050  SSD1306  2xSG90", FW_VERSION);
  }
  else
  {
    printf("ERR unknown command: %s (try HELP)", cmd);
  }

  printf("\r\n> ");
}

static void UART_HandleChar(char ch)
{
  static uint8_t last_was_cr;
  static uint8_t command_mode;

  if ((ch == '\n') && (last_was_cr != 0u))
  {
    last_was_cr = 0u;
    return;
  }
  last_was_cr = (ch == '\r') ? 1u : 0u;

  /* Single-key remote control: no Enter required.
   *   W / S : Pitch (tilt servo) + / - one step
   *   A / D : Yaw   (pan servo)  - / + one step
   * This is the command format required by the course task. */
  if (command_mode == 0u)
  {
    if (ch == ':')
    {
      command_mode = 1u;
      uart_line_len = 0u;
      printf("\r\nCMD> ");
      return;
    }

    /* Advanced task: 1 = PID -30 deg, 2 = PID 0 deg, 0 = PID off. */
    if ((ch == '1') || (ch == '2') || (ch == '0'))
    {
      if (ch == '0')
      {
        PID_Disable();
        printf("\r\nPID OFF  (basic W/S/A/D remote)\r\n> ");
      }
      else if (mpu_state != 1u)
      {
        printf("\r\nERR PID needs MPU6050, current=%s\r\n> ", MPU_StateText());
      }
      else
      {
        PID_Enable((ch == '1') ? -30.0f : 0.0f);
        printf("\r\nPID ON  target=%d deg\r\n> ", (ch == '1') ? -30 : 0);
      }
      return;
    }

    if ((ch == 'W') || (ch == 'w') || (ch == 'S') || (ch == 's')
        || (ch == 'A') || (ch == 'a') || (ch == 'D') || (ch == 'd'))
    {
      char key = (char)toupper((unsigned char)ch);

      if (key == 'W')
      {
        Servo_SetTilt(servo_tilt.target_deg + KEY_STEP_DEG);
      }
      else if (key == 'S')
      {
        Servo_SetTilt(servo_tilt.target_deg - KEY_STEP_DEG);
      }
      else if (key == 'A')
      {
        Servo_SetPan(servo_pan.target_deg - KEY_STEP_DEG);
      }
      else
      {
        Servo_SetPan(servo_pan.target_deg + KEY_STEP_DEG);
      }

      printf("\r\nKEY %c  Yaw=%d  Pitch=%d\r\n> ",
             key,
             (int)(servo_pan.target_deg + 0.5f),
             (int)(servo_tilt.target_deg + 0.5f));
      return;
    }

    if ((ch == '\r') || (ch == '\n'))
    {
      printf("> ");
    }
    return;
  }

  /* command_mode == 1: a ':' prefixed text command, terminated by Enter.
   * Keeping this separate means the letters S/A/D/W inside STATUS, PAN, etc.
   * are not mistaken for single-key movement commands. */
  if ((ch == '\r') || (ch == '\n'))
  {
    command_mode = 0u;
    if (uart_line_len > 0u)
    {
      uart_line[uart_line_len] = '\0';
      uart_line_len = 0u;
      printf("\r\n");
      UART_ProcessLine(uart_line);
    }
    else
    {
      printf("> ");
    }
  }
  else if ((ch == '\b') || (ch == 0x7F))
  {
    if (uart_line_len > 0u)
    {
      uart_line_len--;
      printf("\b \b");
    }
  }
  else if ((ch >= 0x20) && (ch <= 0x7E))
  {
    if (uart_line_len < (uint8_t)(UART_LINE_SIZE - 1u))
    {
      uart_line[uart_line_len++] = ch;
      printf("%c", ch);
    }
  }
}

static void UART_Poll(void)
{
  while (uart_rx_tail != uart_rx_head)
  {
    char ch = (char)uart_rx_ring[uart_rx_tail];
    uart_rx_tail = (uint16_t)((uart_rx_tail + 1u) & (UART_RX_RING_SIZE - 1u));
    UART_HandleChar(ch);
  }
}

static void OLED_ShowMPU(void)
{
  char line0[17];
  char line1[17];
  char line2[17];
  char line3[17];

  if (mpu_state == 1u)
  {
    snprintf(line0, sizeof(line0), "MPU6050 OK%s", (mpu_zero_active != 0u) ? " Z" : "");
    MPU_FormatAngle(line1, sizeof(line1), "Roll : ", MPU_RollRelative());
    MPU_FormatAngle(line2, sizeof(line2), "Pitch: ", MPU_PitchRelative());
    if (PID_IsEnabled() != 0u)
    {
      MPU_FormatAngle(line3, sizeof(line3), "PID T=", PID_GetTarget());
    }
    else
    {
      snprintf(line3, sizeof(line3), "CF a=0.98");
    }
  }
  else
  {
    snprintf(line0, sizeof(line0), "MPU6050");
    snprintf(line1, sizeof(line1), "%s", MPU_StateText());
    snprintf(line2, sizeof(line2), "Check wiring");
    snprintf(line3, sizeof(line3), "AD0=GND 0x68");
  }

  OLED_ShowLines(line0, line1, line2, line3);
}

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_USART1_UART_Init();
  MX_I2C1_Init();
  MX_TIM2_Init();
  /* USER CODE BEGIN 2 */

  /* OLED bring-up: 128x64 SSD1306 on I2C1 (PB6 = SCL, PB7 = SDA).
   * Free a possibly stuck bus, find the panel address, then initialise it. */
  /* Sensors need a little time after power-up before they answer I2C. */
  HAL_Delay(200u);
  oled_state = 0u;
  I2C1_BusRecover();
  I2C1_Scan();
  oled_addr = I2C1_PickOledAddress();

  if (i2c_dev_count == 0u)
  {
    /* Nothing acknowledged at all: check that the panel is powered and that
     * SCL/SDA really land on PB6/PB7. */
    oled_state = 0xE0u;
  }
  else
  {
    uint8_t init_ok = OLED_Init();

    if (!init_ok)
    {
      /* The device answered a probe but rejected the init: reset the bus and
       * give it one more chance. */
      I2C1_BusRecover();
      oled_addr = I2C1_PickOledAddress();
      init_ok = OLED_Init();
    }

    if (!init_ok)
    {
      oled_state = 0xE2u;
    }
    else
    {
      OLED_ClearBuffer();
      OLED_DrawString((uint8_t)((OLED_WIDTH - (11u * 8u)) / 2u), 3u, "Hello STM32");
      oled_state = OLED_Flush() ? 1u : 0xE1u;
    }
  }

  /* MPU6050 on the same I2C1 bus (PB6/PB7), 7-bit address 0x68 (AD0 = GND).
   * The gimbal is first driven to its centre and allowed to settle, because
   * the gyro bias calibration must be done while the platform is still. */
  mpu_state = 0u;
  mpu_mount_mode = MPU_MOUNT_MODE_DEFAULT;
  mpu_roll_zero = 0.0f;
  mpu_pitch_zero = 0.0f;
  mpu_zero_active = 0u;
  mpu_first_sample = 1u;

  servo_speed_dps = SERVO_DEFAULT_SPEED_DPS;
  servo_pan.current_deg = SERVO_CENTER_DEG;
  servo_pan.target_deg = SERVO_CENTER_DEG;
  servo_pan.pulse_us = 1500u;
  servo_tilt.current_deg = SERVO_CENTER_DEG;
  servo_tilt.target_deg = SERVO_CENTER_DEG;
  servo_tilt.pulse_us = 1500u;
  sweep_enabled = 0u;
  stream_enabled = 0u;
  PID_Init();

  (void)HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_1);
  (void)HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_2);
  __HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_1, servo_pan.pulse_us);
  __HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_2, servo_tilt.pulse_us);
  servo_tick = HAL_GetTick();
  HAL_Delay(700u);

  if (MPU_Init())
  {
    OLED_ShowLines("MPU6050", "Calibrating...", "Keep still", "0x68  I2C1");
    (void)MPU_CalibrateGyro();
    if (mpu_state == 1u)
    {
      (void)MPU_UpdateAngles(0.01f);
      /* The MPU6050 is glued to the gimbal, so its mounting direction is not
       * guaranteed.  Use the power-up pose as the 0 degree reference; send
       * ":ZERO RESET" to see the raw absolute angles. */
      mpu_roll_zero = mpu_roll;
      mpu_pitch_zero = mpu_pitch;
      mpu_zero_active = 1u;
    }
  }
  OLED_ShowMPU();

  mpu_tick = HAL_GetTick();
  oled_ui_tick = HAL_GetTick();

  /* UART1 console: 115200 8N1, PA9 = TX, PA10 = RX.
   * The USB-TTL adapter is wired crossed: adapter RX -> PA9, adapter TX ->
   * PA10, GND common. Do not feed 5 V into the 3.3 V board. */
  setvbuf(stdout, NULL, _IONBF, 0);
  uart_report_tick = HAL_GetTick();
  uart_stream_tick = HAL_GetTick();
  uart_raw_tick = HAL_GetTick();
  uart_led_tick = HAL_GetTick();

  printf("\r\n=== STM32F103C8T6 dual-axis gimbal ===\r\n");
  printf("W/S: Pitch +-%d deg   A/D: Yaw +-%d deg (single key)\r\n",
         (int)KEY_STEP_DEG, (int)KEY_STEP_DEG);
  printf("FW %s  UART1 115200 8N1  PA9=TX PA10=RX\r\n", FW_VERSION);
  printf("OLED: %s   MPU6050: %s\r\n",
         (oled_state == 1u) ? "OK" : "NOT DETECTED", MPU_StateText());
  if (mpu_state == 1u)
  {
    printf("MPU address: 0x%02X\r\n", (unsigned)(mpu_addr >> 1));
  }
  printf("I2C scan:");
  for (uint8_t k = 0u; (k < i2c_dev_count) && (k < 8u); k++)
  {
    printf(" 0x%02X", (unsigned)i2c_ack_map[k]);
  }
  printf("\r\n");
  printf("Servo: TIM2_CH1/PA0=pan  TIM2_CH2/PA1=tilt  50Hz 500-2500us\r\n");
  printf("Single key: W/S Pitch, A/D Yaw.  Text commands: :HELP\r\n> ");

  /* Interrupt-driven RX: no command byte is lost during the ~20 ms OLED
   * frame transfer. */
  (void)HAL_UART_Receive_IT(&huart1, &uart_rx_byte, 1u);

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
    uint32_t now;

    /* Pull complete lines out of the interrupt-filled ring buffer. */
    UART_Poll();

    now = HAL_GetTick();

    /* Read the IMU at about 100 Hz.  OLED flushes can stretch a period, so
     * dt is measured instead of assumed. */
    if ((mpu_state == 1u) && ((now - mpu_tick) >= 10u))
    {
      float dt = (float)(now - mpu_tick) / 1000.0f;
      mpu_tick = now;
      (void)MPU_UpdateAngles(dt);

      if (PID_IsEnabled() != 0u)
      {
        if (mpu_state == 1u)
        {
          PID_Update(MPU_PitchRelative(), dt);
        }
        else
        {
          PID_Disable();
          printf("\r\nPID OFF: MPU lost\r\n> ");
        }
      }
    }

    /* Demo path and smooth interpolation toward the serial target. */
    Servo_SweepTask();
    Servo_Update();

    /* Refresh the OLED at 10 Hz; a full 128x64 frame takes ~20 ms on I2C. */
    if ((now - oled_ui_tick) >= 100u)
    {
      oled_ui_tick = now;
      OLED_ShowMPU();
    }

    /* Machine-readable telemetry for the PC-side plotter. */
    if (stream_enabled != 0u)
    {
      if ((mpu_state == 1u) && ((now - uart_stream_tick) >= 200u))
      {
        uart_stream_tick = now;
        UART_PrintData();
      }
      if ((now - uart_raw_tick) >= 1000u)
      {
        uart_raw_tick = now;
        if (mpu_state == 1u)
        {
          UART_PrintRaw();
        }
        else
        {
          printf("MPU: %s\r\n", MPU_StateText());
        }
      }
    }

    /* Heartbeat on the on-board LED (PC13). */
    if ((now - uart_led_tick) >= 500u)
    {
      uart_led_tick = now;
      HAL_GPIO_TogglePin(GPIOC, GPIO_PIN_13);
    }
  }


  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief I2C1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C1_Init(void)
{

  /* USER CODE BEGIN I2C1_Init 0 */

  /* USER CODE END I2C1_Init 0 */

  /* USER CODE BEGIN I2C1_Init 1 */

  /* USER CODE END I2C1_Init 1 */
  hi2c1.Instance = I2C1;
  hi2c1.Init.ClockSpeed = 100000;
  hi2c1.Init.DutyCycle = I2C_DUTYCYCLE_2;
  hi2c1.Init.OwnAddress1 = 0;
  hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2 = 0;
  hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C1_Init 2 */

  /* USER CODE END I2C1_Init 2 */

}

/**
  * @brief TIM2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM2_Init(void)
{

  /* USER CODE BEGIN TIM2_Init 0 */

  /* USER CODE END TIM2_Init 0 */

  /* USER CODE BEGIN TIM2_Init 1 */

  /* USER CODE END TIM2_Init 1 */
  TIM_OC_InitTypeDef sConfigOC = {0};

  htim2.Instance = TIM2;
  htim2.Init.Prescaler = 71;
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim2.Init.Period = 19999;
  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_ENABLE;
  if (HAL_TIM_PWM_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 1500;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  if (HAL_TIM_PWM_ConfigChannel(&htim2, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_ConfigChannel(&htim2, &sConfigOC, TIM_CHANNEL_2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM2_Init 2 */

  /* USER CODE END TIM2_Init 2 */

}

/**
  * @brief USART1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART1_UART_Init(void)
{

  /* USER CODE BEGIN USART1_Init 0 */

  /* USER CODE END USART1_Init 0 */

  /* USER CODE BEGIN USART1_Init 1 */

  /* USER CODE END USART1_Init 1 */
  huart1.Instance = USART1;
  huart1.Init.BaudRate = 115200;
  huart1.Init.WordLength = UART_WORDLENGTH_8B;
  huart1.Init.StopBits = UART_STOPBITS_1;
  huart1.Init.Parity = UART_PARITY_NONE;
  huart1.Init.Mode = UART_MODE_TX_RX;
  huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart1.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART1_Init 2 */

  /* USER CODE END USART1_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  /* USER CODE BEGIN MX_GPIO_Init_1 */

  /* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_RESET);

  /*Configure GPIO pin : PC13 */
  GPIO_InitStruct.Pin = GPIO_PIN_13;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /* USER CODE BEGIN MX_GPIO_Init_2 */

  /* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

/* USART1 interrupt vector: receives one byte at a time into the ring buffer. */
void USART1_IRQHandler(void)
{
  HAL_UART_IRQHandler(&huart1);
}

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
  if (huart->Instance == USART1)
  {
    uint16_t next = (uint16_t)((uart_rx_head + 1u) & (UART_RX_RING_SIZE - 1u));

    if (next != uart_rx_tail)
    {
      uart_rx_ring[uart_rx_head] = uart_rx_byte;
      uart_rx_head = next;
    }
    (void)HAL_UART_Receive_IT(&huart1, &uart_rx_byte, 1u);
  }
}

void HAL_UART_ErrorCallback(UART_HandleTypeDef *huart)
{
  if (huart->Instance == USART1)
  {
    __HAL_UART_CLEAR_OREFLAG(huart);
    huart->ErrorCode = HAL_UART_ERROR_NONE;
    (void)HAL_UART_Receive_IT(&huart1, &uart_rx_byte, 1u);
  }
}

/* Retarget the newlib printf()/putchar() path to USART1. syscalls.c already
 * routes _write() through this weak __io_putchar() hook. */
int __io_putchar(int ch)
{
  uint8_t byte = (uint8_t)ch;
  (void)HAL_UART_Transmit(&huart1, &byte, 1u, 100u);
  return ch;
}

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

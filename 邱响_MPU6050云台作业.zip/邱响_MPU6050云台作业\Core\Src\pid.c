#include "pid.h"
#include <math.h>

/* Conservative gains for a slow SG90 gimbal.  The output is in microseconds:
 * one degree of servo command is about 11.1 us with the 500-2500 us mapping. */
#define PID_KP                 8.0f
#define PID_KI                 1.0f
#define PID_KD                 0.5f
#define PID_OUTPUT_LIMIT_US    400.0f
#define PID_INTEGRAL_LIMIT     60.0f
#define PID_OUTPUT_SLEW_US     30.0f

static uint8_t pid_enabled;
static float   pid_target;
static float   pid_integral;
static float   pid_prev_measured;
static float   pid_measured_rate;
static float   pid_output;

void PID_Init(void)
{
  pid_enabled = 0u;
  pid_target = 0.0f;
  pid_integral = 0.0f;
  pid_prev_measured = 0.0f;
  pid_measured_rate = 0.0f;
  pid_output = 0.0f;
}

void PID_Enable(float target_deg)
{
  pid_target = target_deg;
  pid_integral = 0.0f;
  pid_prev_measured = 0.0f;
  pid_measured_rate = 0.0f;
  pid_output = 0.0f;
  pid_enabled = 1u;
}

void PID_Disable(void)
{
  pid_enabled = 0u;
  pid_integral = 0.0f;
  pid_measured_rate = 0.0f;
  pid_output = 0.0f;
}

uint8_t PID_IsEnabled(void)
{
  return pid_enabled;
}

float PID_GetTarget(void)
{
  return pid_target;
}

float PID_GetOutput(void)
{
  return pid_output;
}

void PID_Update(float measured_deg, float dt)
{
  float error;
  float derivative;
  float raw_output;
  float delta;

  if (pid_enabled == 0u)
  {
    pid_output = 0.0f;
    return;
  }

  if ((dt <= 0.0f) || (dt > 0.1f))
  {
    dt = 0.01f;
  }

  error = pid_target - measured_deg;

  /* Derivative on measurement, not on the error, so changing the target does
   * not produce a large derivative kick. */
  pid_measured_rate = (0.7f * pid_measured_rate)
                    + (0.3f * ((measured_deg - pid_prev_measured) / dt));
  derivative = -PID_KD * pid_measured_rate;

  raw_output = PID_PITCH_SIGN
             * ((PID_KP * error) + (PID_KI * pid_integral) + derivative);

  /* Conditional integration avoids wind-up while the output is saturated. */
  if (((raw_output < PID_OUTPUT_LIMIT_US) && (raw_output > -PID_OUTPUT_LIMIT_US))
      || ((raw_output >= PID_OUTPUT_LIMIT_US) && (error < 0.0f))
      || ((raw_output <= -PID_OUTPUT_LIMIT_US) && (error > 0.0f)))
  {
    pid_integral += error * dt;
    if (pid_integral > PID_INTEGRAL_LIMIT)
    {
      pid_integral = PID_INTEGRAL_LIMIT;
    }
    else if (pid_integral < -PID_INTEGRAL_LIMIT)
    {
      pid_integral = -PID_INTEGRAL_LIMIT;
    }
  }

  if (raw_output > PID_OUTPUT_LIMIT_US)
  {
    raw_output = PID_OUTPUT_LIMIT_US;
  }
  else if (raw_output < -PID_OUTPUT_LIMIT_US)
  {
    raw_output = -PID_OUTPUT_LIMIT_US;
  }

  /* Slew-limit the offset so enabling PID does not slam the servo. */
  delta = raw_output - pid_output;
  if (delta > PID_OUTPUT_SLEW_US)
  {
    delta = PID_OUTPUT_SLEW_US;
  }
  else if (delta < -PID_OUTPUT_SLEW_US)
  {
    delta = -PID_OUTPUT_SLEW_US;
  }
  pid_output += delta;

  pid_prev_measured = measured_deg;
}
